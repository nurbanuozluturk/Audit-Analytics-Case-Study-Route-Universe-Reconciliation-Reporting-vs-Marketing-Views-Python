# Audit Findings – Numeric Summary (Auto-generated)

## Coverage & Exceptions
- Reporting unique routes: **5,649**
- Marketing unique routes: **5,967**
- Reporting coverage of marketing route universe: **5,649 / 5,967 (94.7%)**
- Marketing-only routes (exceptions): **318 (5.3%)**
- Airports only in Marketing view: **23**

## Overcounting / Population Definition Flags
- Flagged routes: **48** (rep_count ≥ 20 and ratio ≥ 3.0)
- Ratio stats: median **3.67**, max **8.09**

## Samples
**Marketing-only routes (first 5):**
- ORIGIN=10135, DEST=10397
- ORIGIN=10135, DEST=13930
- ORIGIN=10140, DEST=14057
- ORIGIN=10185, DEST=10397
- ORIGIN=10245, DEST=10299

**Top 5 overcounting flags:**
- ORIGIN=11618, DEST=11278 | rep=33, mkt=267, ratio=8.09
- ORIGIN=11278, DEST=11618 | rep=33, mkt=266, ratio=8.06
- ORIGIN=13158, DEST=12266 | rep=33, mkt=189, ratio=5.73
- ORIGIN=12266, DEST=13158 | rep=34, mkt=190, ratio=5.59
- ORIGIN=11433, DEST=12478 | rep=23, mkt=120, ratio=5.22